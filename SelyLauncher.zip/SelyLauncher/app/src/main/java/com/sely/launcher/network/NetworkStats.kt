package com.sely.launcher.network

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.provider.Settings
import android.telephony.TelephonyManager

/**
 * Sely Network Center (spec section 14) — data layer.
 *
 * 🟢 Connection type (Wi-Fi vs cellular), carrier name, Bluetooth paired
 * devices, and airplane mode status are all read via standard,
 * permission-light APIs.
 *
 * 🟡 Wi-Fi SSID specifically requires ACCESS_FINE_LOCATION on modern
 * Android (a real, deliberate OS privacy rule — SSID can reveal
 * location). If not granted, this shows "Wi-Fi connected" without the
 * network name rather than either faking a name or forcing the
 * permission on someone who doesn't want to grant it for this.
 *
 * 🔴 Whether the mobile hotspot is currently on has no public, reliable
 * API on modern Android (the old `WifiManager.isWifiApEnabled` is
 * hidden/reflection-only and unofficial) — NetworkCenterActivity links
 * to the real system hotspot screen instead of guessing.
 */
data class NetworkSnapshot(
    val connectionType: String,
    val wifiSsid: String?,
    val wifiLinkSpeedMbps: Int?,
    val carrierName: String?,
    val airplaneModeOn: Boolean,
    val bluetoothEnabled: Boolean,
    val pairedBluetoothDevices: List<String>
)

object NetworkStats {

    fun snapshot(context: Context): NetworkSnapshot {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork
        val capabilities = network?.let { connectivityManager.getNetworkCapabilities(it) }

        val connectionType = when {
            capabilities == null -> "No connection"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Connected"
        }

        var ssid: String? = null
        var linkSpeed: Int? = null
        if (connectionType == "Wi-Fi") {
            val hasLocation = context.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val info = wifiManager.connectionInfo
            if (hasLocation) {
                val rawSsid = info?.ssid?.removeSurrounding("\"")
                ssid = if (rawSsid.isNullOrBlank() || rawSsid == "<unknown ssid>") null else rawSsid
            }
            linkSpeed = info?.linkSpeed?.takeIf { it > 0 }
        }

        val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val carrier = telephonyManager.networkOperatorName?.takeIf { it.isNotBlank() }

        val airplaneMode = Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) != 0

        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        val bluetoothEnabled = bluetoothAdapter?.isEnabled == true
        val pairedDevices = if (bluetoothEnabled &&
            context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        ) {
            try {
                bluetoothAdapter.bondedDevices?.map { it.name ?: it.address } ?: emptyList()
            } catch (e: SecurityException) {
                emptyList()
            }
        } else emptyList()

        return NetworkSnapshot(
            connectionType = connectionType,
            wifiSsid = ssid,
            wifiLinkSpeedMbps = linkSpeed,
            carrierName = carrier,
            airplaneModeOn = airplaneMode,
            bluetoothEnabled = bluetoothEnabled,
            pairedBluetoothDevices = pairedDevices
        )
    }
}
