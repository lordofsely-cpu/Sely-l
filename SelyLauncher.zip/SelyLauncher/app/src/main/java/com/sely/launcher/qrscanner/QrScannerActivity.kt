package com.sely.launcher.qrscanner

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.sely.launcher.databinding.ActivityQrScannerBinding
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Sely QR/Barcode Center (spec section 21).
 *
 * 🟢 Real, working scanner: CameraX drives the live preview and feeds
 * frames to ML Kit's on-device Barcode Scanning model (Google's current
 * official library for this — no network call per scan, no cloud
 * round-trip, decoding happens on-device). Requires the device to have
 * Google Play services available, which is the case for the vast
 * majority of real Android phones but worth naming as a dependency
 * rather than assuming universally.
 *
 * Once a code is found: Open (if it's a URL), Copy, Share, or Scan
 * again — all real, standard Android actions. Scanning pauses after a
 * hit so the same code isn't processed repeatedly; "Scan again" resumes
 * analysis.
 */
class QrScannerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQrScannerBinding
    private lateinit var cameraExecutor: ExecutorService
    private val cameraPermissionCode = 701
    private var scanningPaused = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQrScannerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.resultScanNext.setOnClickListener {
            binding.resultCard.visibility = android.view.View.GONE
            scanningPaused = false
        }

        if (hasCameraPermission()) {
            startCamera()
        } else {
            binding.permissionPrompt.visibility = android.view.View.VISIBLE
            binding.permissionPrompt.setOnClickListener {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), cameraPermissionCode)
            }
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), cameraPermissionCode)
        }
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == cameraPermissionCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            binding.permissionPrompt.visibility = android.view.View.GONE
            startCamera()
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val cameraProvider = providerFuture.get()

            val preview = androidx.camera.core.Preview.Builder().build().also {
                it.setSurfaceProvider(binding.cameraPreview.surfaceProvider)
            }

            val scanner = BarcodeScanning.getClient()
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { imageProxy -> analyzeFrame(imageProxy, scanner) }
                }

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis
                )
            } catch (e: Exception) {
                // Device/OEM camera binding failure — nothing to fake here,
                // just leave the preview blank rather than crash.
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.camera.core.ExperimentalGetImage
    private fun analyzeFrame(imageProxy: ImageProxy, scanner: com.google.mlkit.vision.barcode.BarcodeScanner) {
        if (scanningPaused || imageProxy.image == null) {
            imageProxy.close()
            return
        }
        val image = InputImage.fromMediaImage(imageProxy.image!!, imageProxy.imageInfo.rotationDegrees)
        scanner.process(image)
            .addOnSuccessListener { barcodes ->
                val first = barcodes.firstOrNull { !it.rawValue.isNullOrBlank() }
                if (first != null) {
                    scanningPaused = true
                    runOnUiThread { showResult(first) }
                }
            }
            .addOnCompleteListener { imageProxy.close() }
    }

    private fun showResult(barcode: Barcode) {
        val text = barcode.rawValue ?: return
        val formatLabel = when (barcode.valueType) {
            Barcode.TYPE_URL -> "Link"
            Barcode.TYPE_TEXT -> "Text"
            Barcode.TYPE_WIFI -> "Wi-Fi"
            Barcode.TYPE_CONTACT_INFO -> "Contact"
            else -> "Code"
        }
        binding.resultFormat.text = formatLabel
        binding.resultText.text = text
        binding.resultCard.visibility = android.view.View.VISIBLE

        val isUrl = barcode.valueType == Barcode.TYPE_URL || text.startsWith("http")
        binding.resultOpen.visibility = if (isUrl) android.view.View.VISIBLE else android.view.View.GONE

        binding.resultOpen.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(text)))
        }
        binding.resultCopy.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Scanned code", text))
        }
        binding.resultShare.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            startActivity(Intent.createChooser(shareIntent, "Share via"))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
